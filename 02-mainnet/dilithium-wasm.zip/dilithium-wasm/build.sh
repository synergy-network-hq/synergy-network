#!/bin/bash
set -euo pipefail
EMCC=emcc
SRC_DIR=$(dirname "$0")/src
OUT_DIR=$(dirname "$0")
CFILES=(
  sign.c
  packing.c
  polyvec.c
  poly.c
  ntt.c
  reduce.c
  rounding.c
  symmetric-shake.c
  fips202.c
)

for f in "${CFILES[@]}"; do
  FILES+="$SRC_DIR/$f "
done
FILES+="$(dirname "$0")/wasm_randombytes.c $(dirname "$0")/wasm_wrapper.c"

# Corrected emcc command with increased stack size
$EMCC -O3 -DDILITHIUM_MODE=3 \
  $FILES -I"$SRC_DIR" \
  -s EXPORTED_RUNTIME_METHODS="['ccall','cwrap','getValue','setValue','UTF8ToString','stringToUTF8','HEAPU8','HEAPU32']" \
  -s EXPORTED_FUNCTIONS="['_dilithium3_keypair','_dilithium3_sign','_dilithium3_verify','_malloc','_free']" \
  -s EXPORT_ES6=1 \
  -s MODULARIZE=1 \
  -s ENVIRONMENT=web \
  -s EXPORT_NAME="DilithiumModule" \
  -s ALLOW_MEMORY_GROWTH=1 \
  -s TOTAL_MEMORY=16777216 \
  -s TOTAL_STACK=8388608 \
  -o "$OUT_DIR/dilithium_wasm.js"

echo "Build complete: $OUT_DIR/dilithium_wasm.js"
